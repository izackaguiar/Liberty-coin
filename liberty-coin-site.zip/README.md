# Liberty Coin (LBC)

🚀 **A nova moeda de troca na rede Ethereum e Binance Smart Chain**

## 📌 Sobre
A **Liberty Coin (LBC)** é uma criptomoeda desenvolvida para ser um meio de troca seguro, rápido e descentralizado. 
Possui um fornecimento total de **1.000.000 LBC** e será lançada simultaneamente nas redes **Ethereum** e **Binance Smart Chain**.

## 🔹 Detalhes do Token
- **Nome:** Liberty Coin
- **Símbolo:** LBC
- **Suprimento Total:** 1.000.000
- **Redes:** Ethereum e Binance Smart Chain
- **Carteira Oficial BNB:** `0x2e9be274146dec0321ed3c62651d3fbcbc7ed518`
- **Data de Lançamento:** 07/08/2025

## 🌐 Como Adquirir?
Em breve você poderá comprar Liberty Coin através de corretoras parceiras e swaps descentralizados.

## 📄 Licença
Este projeto é de código aberto.
